from Visitor import Visitor


class StaticChecker(Visitor):
    pass
